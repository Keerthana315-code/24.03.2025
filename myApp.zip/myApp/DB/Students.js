let students = [
    { Reg_No: "2021ict109", name: "Shama", course: "IT", gender: "Female" },
    { Reg_No: "2021ict100", name: "Rama", course: "Bio", gender: "Female" },
    { Reg_No: "2021ict45", name: "Chuma", course: "Math", gender: "Male" },
    { Reg_No: "2021ict89", name: "Kumar", course: "IT", gender: "Male" },
    { Reg_No: "2021ict79", name: "Raj", course: "Math", gender: "Male" }
];

module.exports=students;